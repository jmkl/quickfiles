//! Plain data types shared between the UI and the worker thread. No egui here.

use std::borrow::Cow;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum EntryKind {
    Folder,
    Html,
    Script,
    Json,
    Other,
}

#[derive(Debug)]
pub struct FileEntry {
    pub name: String,
    /// Lower-cased name, computed once on the worker thread (cheap sorting + filtering).
    pub key: String,
    pub kind: EntryKind,
    pub type_label: &'static str,
    pub modified: String, // ISO-like, so plain string comparison sorts chronologically
    pub folders: Option<u32>,
    pub files: Option<u32>,
    pub size_bytes: u64,
}

impl FileEntry {
    pub fn is_dir(&self) -> bool {
        self.kind == EntryKind::Folder
    }
}

/// Result of scanning one directory.
#[derive(Debug)]
pub struct Listing {
    pub entries: Vec<FileEntry>,
    pub folder_count: usize,
    pub file_count: usize,
    pub scan_secs: f32,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum SortKey {
    Name,
    Type,
    Modified,
    Size,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum SortDir {
    Asc,
    Desc,
}

#[derive(Clone, Copy, Debug)]
pub struct Sort {
    pub key: SortKey,
    pub dir: SortDir,
}

impl Sort {
    pub fn toggle(&mut self, key: SortKey) {
        if self.key == key {
            self.dir = match self.dir {
                SortDir::Asc => SortDir::Desc,
                SortDir::Desc => SortDir::Asc,
            };
        } else {
            *self = Self {
                key,
                dir: SortDir::Asc,
            };
        }
    }
}

// --- Sidebar --------------------------------------------------------------------------------

#[derive(Clone, Copy)]
pub enum SideKind {
    Folder,
    Drive,
    Pc,
}

#[derive(Clone, Copy)]
pub struct SideItem {
    pub label: &'static str,
    pub kind: SideKind,
}

#[derive(Clone, Copy)]
pub struct DriveInfo {
    pub label: &'static str,
    /// 0.0..=1.0
    pub used: f32,
    pub system: bool,
}

impl DriveInfo {
    pub fn nearly_full(&self) -> bool {
        self.used >= 0.9
    }
}

// --- Formatting -----------------------------------------------------------------------------

pub fn format_size(bytes: u64) -> String {
    const UNITS: [&str; 4] = ["B", "KB", "MB", "GB"];
    if bytes < 1024 {
        return format!("{bytes} B");
    }
    let mut value = bytes as f64;
    let mut unit = 0;
    while value >= 1024.0 && unit < UNITS.len() - 1 {
        value /= 1024.0;
        unit += 1;
    }
    let text = format!("{value:.1}");
    let text = text.strip_suffix(".0").unwrap_or(&text);
    format!("{text} {}", UNITS[unit])
}

pub fn count_text(n: Option<u32>) -> Cow<'static, str> {
    match n {
        Some(n) => Cow::Owned(n.to_string()),
        None => Cow::Borrowed("--"),
    }
}
