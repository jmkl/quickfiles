//! All mutable UI state, free of any drawing code.

use std::{collections::HashSet, sync::Arc};

use crate::{
    data,
    model::{Listing, Sort, SortDir, SortKey},
};

pub struct Tab {
    pub title: String,
}

pub struct State {
    // Window chrome
    pub tabs: Vec<Tab>,
    pub active_tab: usize,
    pub sidebar_open: bool,
    /// Recents, Bookmarks, Storage, Places
    pub section_open: [bool; 4],
    pub sidebar_filter: String,

    // Navigation
    pub path: Vec<String>,
    pub back: Vec<Vec<String>>,
    pub forward: Vec<Vec<String>>,

    // Listing
    pub listing: Option<Arc<Listing>>,
    pub request_id: u64,
    pub loading: bool,
    pub sort: Sort,
    pub filter: String,
    /// Indices into `listing.entries`, already filtered and sorted. Rebuilt only on change.
    pub view: Vec<u32>,
    pub selected: HashSet<u32>,
    pub focused: Option<u32>,
}

impl State {
    pub fn new() -> Self {
        let path: Vec<String> = data::DEFAULT_PATH.iter().map(|s| (*s).to_owned()).collect();
        Self {
            tabs: vec![Tab {
                title: path.last().cloned().unwrap_or_default(),
            }],
            active_tab: 0,
            sidebar_open: true,
            section_open: [true; 4],
            sidebar_filter: String::new(),
            path,
            back: Vec::new(),
            forward: Vec::new(),
            listing: None,
            request_id: 0,
            loading: false,
            sort: Sort {
                key: SortKey::Name,
                dir: SortDir::Asc,
            },
            filter: String::new(),
            view: Vec::new(),
            selected: HashSet::new(),
            focused: None,
        }
    }

    pub fn entry_count(&self) -> usize {
        self.listing.as_ref().map_or(0, |l| l.entries.len())
    }

    pub fn set_listing(&mut self, listing: Arc<Listing>) {
        self.listing = Some(listing);
        self.loading = false;
        self.selected.clear();
        self.rebuild_view();
        self.focused = self.view.first().copied();
        if let Some(tab) = self.tabs.get_mut(self.active_tab) {
            tab.title = self.path.last().cloned().unwrap_or_default();
        }
    }

    pub fn toggle_sort(&mut self, key: SortKey) {
        self.sort.toggle(key);
        self.rebuild_view();
    }

    /// Re-filter and re-sort. Called only when the listing, filter or sort changes - never per frame.
    pub fn rebuild_view(&mut self) {
        self.view.clear();
        let Some(listing) = self.listing.clone() else {
            return;
        };
        let entries = &listing.entries;
        let needle = self.filter.to_lowercase();

        self.view.extend(
            (0..entries.len() as u32)
                .filter(|&i| needle.is_empty() || entries[i as usize].key.contains(&needle)),
        );

        let (key, dir) = (self.sort.key, self.sort.dir);
        self.view.sort_by(|&a, &b| {
            let (a, b) = (&entries[a as usize], &entries[b as usize]);
            let inner = match key {
                SortKey::Name => a.key.cmp(&b.key),
                SortKey::Type => a
                    .type_label
                    .cmp(b.type_label)
                    .then_with(|| a.key.cmp(&b.key)),
                SortKey::Modified => a.modified.cmp(&b.modified),
                SortKey::Size => a.size_bytes.cmp(&b.size_bytes),
            };
            let inner = if dir == SortDir::Desc {
                inner.reverse()
            } else {
                inner
            };
            // Folders always first.
            b.is_dir().cmp(&a.is_dir()).then(inner)
        });
    }
}
