//! Glue: owns the theme, the state and the worker; turns UI `Action`s into state changes.

use eframe::egui;

use crate::{
    state::{State, Tab},
    theme::Theme,
    ui::{self, Action, Cx},
    worker::{Command, Event, Worker},
};

pub struct App {
    theme: Theme,
    state: State,
    worker: Worker,
}

impl App {
    pub fn new(cc: &eframe::CreationContext<'_>) -> Self {
        let theme = Theme::dark();
        theme.apply(&cc.egui_ctx);

        let mut app = Self {
            theme,
            state: State::new(),
            worker: Worker::spawn(cc.egui_ctx.clone()),
        };
        app.load_current();
        app
    }

    fn load_current(&mut self) {
        self.state.request_id += 1;
        self.state.loading = true;
        self.worker.send(Command::Load {
            id: self.state.request_id,
            path: self.state.path.clone(),
        });
    }

    fn pump_worker(&mut self) {
        for event in self.worker.events() {
            match event {
                // Ignore results of requests the user has already navigated away from.
                Event::Loaded { id, listing } if id == self.state.request_id => {
                    self.state.set_listing(listing);
                }
                Event::Loaded { .. } => {}
            }
        }
    }

    fn navigate(&mut self, path: Vec<String>) {
        if path == self.state.path {
            return;
        }
        let old = std::mem::replace(&mut self.state.path, path);
        self.state.back.push(old);
        self.state.forward.clear();
        self.load_current();
    }

    fn apply(&mut self, action: Action) {
        match action {
            Action::Navigate(path) => self.navigate(path),
            Action::OpenFolder(name) => {
                let mut path = self.state.path.clone();
                path.push(name);
                self.navigate(path);
            }
            Action::Up => {
                if self.state.path.len() > 1 {
                    let mut path = self.state.path.clone();
                    path.pop();
                    self.navigate(path);
                }
            }
            Action::Back => {
                if let Some(prev) = self.state.back.pop() {
                    let current = std::mem::replace(&mut self.state.path, prev);
                    self.state.forward.push(current);
                    self.load_current();
                }
            }
            Action::Forward => {
                if let Some(next) = self.state.forward.pop() {
                    let current = std::mem::replace(&mut self.state.path, next);
                    self.state.back.push(current);
                    self.load_current();
                }
            }
            Action::NewTab => {
                self.state.tabs.push(Tab {
                    title: "This PC".to_owned(),
                });
                self.state.active_tab = self.state.tabs.len() - 1;
            }
            Action::SelectTab(i) => {
                if i < self.state.tabs.len() {
                    self.state.active_tab = i;
                }
            }
            Action::CloseTab(i) => {
                if self.state.tabs.len() > 1 && i < self.state.tabs.len() {
                    self.state.tabs.remove(i);
                    self.state.active_tab = self.state.active_tab.min(self.state.tabs.len() - 1);
                }
            }
        }
    }
}

impl eframe::App for App {
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        self.pump_worker();

        let mut actions = Vec::new();
        egui::CentralPanel::default()
            .frame(egui::Frame::NONE)
            .show(ui, |panel_ui| {
                let mut cx = Cx {
                    theme: &self.theme,
                    state: &mut self.state,
                    actions: &mut actions,
                };
                ui::draw(panel_ui, &mut cx);
            });

        for action in actions {
            self.apply(action);
        }
    }
}
