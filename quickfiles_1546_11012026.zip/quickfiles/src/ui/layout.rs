//! Splits the window into the fixed regions of the layout.

use eframe::egui::{Rect, pos2, vec2};

use crate::theme::Metrics;

pub struct Regions {
    pub title: Rect,
    pub sidebar: Option<Rect>,
    pub toolbar: Rect,
    pub header: Rect,
    pub list: Rect,
    pub status: Rect,
}

impl Regions {
    pub fn compute(full: Rect, m: &Metrics, sidebar_open: bool) -> Self {
        let title = Rect::from_min_size(full.min, vec2(full.width(), m.title_h));
        let body_top = title.bottom();
        let main_left = if sidebar_open {
            full.left() + m.sidebar_w
        } else {
            full.left()
        };

        let sidebar = sidebar_open.then(|| {
            Rect::from_min_max(pos2(full.left(), body_top), pos2(main_left, full.bottom()))
        });
        let toolbar = Rect::from_min_max(
            pos2(main_left, body_top),
            pos2(full.right(), body_top + m.toolbar_h),
        );
        let header = Rect::from_min_max(
            pos2(main_left, toolbar.bottom()),
            pos2(full.right(), toolbar.bottom() + m.header_h),
        );
        let status = Rect::from_min_max(
            pos2(main_left, full.bottom() - m.status_h),
            full.right_bottom(),
        );
        let list = Rect::from_min_max(
            pos2(main_left, header.bottom()),
            pos2(full.right(), status.top()),
        );

        Self {
            title,
            sidebar,
            toolbar,
            header,
            list,
            status,
        }
    }
}
