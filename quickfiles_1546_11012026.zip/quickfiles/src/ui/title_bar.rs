//! Custom title bar: hamburger, sidebar toggle, tabs, "+" and window buttons.

use eframe::egui::{
    self, Color32, CornerRadius, Rect, Sense, Shape, Stroke, Ui, ViewportCommand, pos2, vec2,
};

use super::{
    Action, Cx,
    icons::{self, Icon},
    widgets::{btn_size, hit, hline, icon_button, text_left, top_outline},
};

pub fn show(ui: &mut Ui, cx: &mut Cx<'_>, r: Rect) {
    let th = cx.theme;
    let (pal, m) = (&th.palette, &th.metrics);
    let p = ui.painter().clone();
    let ctx = ui.ctx().clone();

    p.rect_filled(r, 0.0, pal.chrome);
    hline(&p, r.bottom() - 1.0, r.left(), r.right(), pal.border);

    // Whole bar drags the window; double-click toggles maximise. Registered first so the
    // buttons drawn after it take priority.
    let drag = hit(ui, r, "titlebar_drag", Sense::click_and_drag());
    if drag.drag_started() {
        ctx.send_viewport_cmd(ViewportCommand::StartDrag);
    }
    if drag.double_clicked() {
        let maximized = ctx.input(|i| i.viewport().maximized.unwrap_or(false));
        ctx.send_viewport_cmd(ViewportCommand::Maximized(!maximized));
    }

    // Left controls
    let cy = r.top() + 16.5;
    if icon_button(
        ui,
        th,
        Icon::Menu,
        pos2(r.left() + 19.5, cy),
        vec2(32.0, 26.0),
        "menu",
        true,
    )
    .clicked()
    {
        // Hook for an app menu.
    }
    if icon_button(
        ui,
        th,
        Icon::SidebarToggle,
        pos2(r.left() + 230.5, cy),
        vec2(30.0, 26.0),
        "sidebar_toggle",
        true,
    )
    .clicked()
    {
        cx.state.sidebar_open = !cx.state.sidebar_open;
    }

    // Tabs
    let tab_step = m.tab_w - 1.0; // neighbours share a border pixel
    let tab_x0 = r.left() + m.tab_left;
    let font = &th.font;
    for i in 0..cx.state.tabs.len() {
        let rect = Rect::from_min_max(
            pos2(tab_x0 + i as f32 * tab_step, r.top() + m.tab_top),
            pos2(tab_x0 + i as f32 * tab_step + m.tab_w, r.bottom()),
        );
        let active = i == cx.state.active_tab;
        let body = hit(ui, rect, ("tab", i), Sense::click());
        if body.clicked() {
            cx.actions.push(Action::SelectTab(i));
        }

        if active {
            let radius = CornerRadius {
                nw: m.tab_radius as u8,
                ne: m.tab_radius as u8,
                sw: 0,
                se: 0,
            };
            p.rect_filled(rect, radius, pal.main);
            p.add(Shape::line(
                top_outline(rect, m.tab_radius, m.tab_radius),
                Stroke::new(1.0, pal.border),
            ));
        } else if body.hovered() {
            p.rect_filled(rect.shrink2(vec2(4.0, 3.0)), m.radius, pal.hover);
        }

        let cy = rect.top() + 14.0;
        icons::paint(
            &p,
            pal,
            Icon::Folder,
            pos2(rect.left() + 20.5, cy),
            pal.folder,
        );
        let color = if active { pal.text } else { pal.text_dim };
        let max_w = m.tab_w - 35.0 - 28.0;
        text_left(
            &p,
            rect.left() + 35.0,
            cy,
            &cx.state.tabs[i].title,
            font,
            color,
            max_w,
        );

        let close = icon_button_small(
            ui,
            th,
            Icon::Close,
            pos2(rect.right() - 18.5, cy),
            ("tab_close", i),
        );
        if close.clicked() {
            cx.actions.push(Action::CloseTab(i));
        }
    }

    // "+" new tab
    let last_right = tab_x0 + (cx.state.tabs.len() - 1) as f32 * tab_step + m.tab_w;
    if icon_button(
        ui,
        th,
        Icon::Plus,
        pos2(last_right + 20.5, r.top() + 17.0),
        btn_size(),
        "new_tab",
        true,
    )
    .clicked()
    {
        cx.actions.push(Action::NewTab);
    }

    // Window buttons, right-aligned
    let bw = m.win_btn_w;
    let button = |slot: f32| {
        Rect::from_min_size(
            pos2(r.right() - bw * (slot + 1.0), r.top()),
            vec2(bw, r.height() - 1.0),
        )
    };
    let icon_cy = r.top() + 16.0;

    // Tab list dropdown (decorative)
    let rect = button(3.0);
    window_button(
        ui,
        th,
        rect,
        Icon::ChevronDown,
        0.9,
        "tab_list",
        pal.hover,
        icon_cy,
    );

    let rect = button(2.0);
    if window_button(
        ui,
        th,
        rect,
        Icon::Minimize,
        1.0,
        "win_min",
        pal.hover,
        icon_cy,
    )
    .clicked()
    {
        ctx.send_viewport_cmd(ViewportCommand::Minimized(true));
    }

    let rect = button(1.0);
    if window_button(
        ui,
        th,
        rect,
        Icon::Maximize,
        1.0,
        "win_max",
        pal.hover,
        icon_cy,
    )
    .clicked()
    {
        let maximized = ctx.input(|i| i.viewport().maximized.unwrap_or(false));
        ctx.send_viewport_cmd(ViewportCommand::Maximized(!maximized));
    }

    let rect = button(0.0);
    if window_button(
        ui,
        th,
        rect,
        Icon::Close,
        1.0,
        "win_close",
        pal.close_hover,
        icon_cy,
    )
    .clicked()
    {
        ctx.send_viewport_cmd(ViewportCommand::Close);
    }
}

fn icon_button_small(
    ui: &Ui,
    th: &crate::theme::Theme,
    icon: Icon,
    center: egui::Pos2,
    salt: impl std::hash::Hash + std::fmt::Debug,
) -> egui::Response {
    let rect = Rect::from_center_size(center, vec2(18.0, 18.0));
    let response = hit(ui, rect, salt, Sense::click());
    let pal = &th.palette;
    let p = ui.painter();
    if response.hovered() {
        p.rect_filled(rect, th.metrics.radius, pal.hover);
    }
    let tint = if response.hovered() {
        pal.icon_strong
    } else {
        pal.text_section
    };
    icons::paint_scaled(p, pal, icon, center, tint, 0.8);
    response
}

#[allow(clippy::too_many_arguments)]
fn window_button(
    ui: &Ui,
    th: &crate::theme::Theme,
    rect: Rect,
    icon: Icon,
    scale: f32,
    salt: &'static str,
    hover_fill: Color32,
    icon_cy: f32,
) -> egui::Response {
    let pal = &th.palette;
    let response = hit(ui, rect, salt, Sense::click());
    let p = ui.painter();
    if response.hovered() {
        p.rect_filled(rect, 0.0, hover_fill);
    }
    let tint = if response.hovered() && hover_fill == pal.close_hover {
        Color32::WHITE
    } else {
        pal.icon
    };
    icons::paint_scaled(p, pal, icon, pos2(rect.center().x, icon_cy), tint, scale);
    response
}
