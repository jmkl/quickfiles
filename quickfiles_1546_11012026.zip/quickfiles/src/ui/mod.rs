//! Immediate-mode UI. Each region lives in its own module and draws itself into a fixed rect
//! computed by [`layout::Regions`]. Modules read the [`Theme`], mutate view-state directly,
//! and request anything with side effects (navigation, tabs) through [`Action`].

mod file_list;
mod icons;
mod layout;
mod sidebar;
mod status_bar;
mod title_bar;
mod toolbar;
mod widgets;

use eframe::egui::Ui;

use crate::{state::State, theme::Theme};

/// Side effects the UI asks the app to perform after the frame.
pub enum Action {
    Navigate(Vec<String>),
    OpenFolder(String),
    Back,
    Forward,
    Up,
    NewTab,
    CloseTab(usize),
    SelectTab(usize),
}

/// Everything a region needs while drawing.
pub struct Cx<'a> {
    pub theme: &'a Theme,
    pub state: &'a mut State,
    pub actions: &'a mut Vec<Action>,
}

pub fn draw(ui: &mut Ui, cx: &mut Cx<'_>) {
    let theme = cx.theme;
    let full = ui.max_rect();
    let regions = layout::Regions::compute(full, &theme.metrics, cx.state.sidebar_open);

    ui.painter().rect_filled(full, 0.0, theme.palette.main);

    file_list::show(ui, cx, regions.header, regions.list);
    toolbar::show(ui, cx, regions.toolbar);
    status_bar::show(ui, cx, regions.status);
    if let Some(sidebar) = regions.sidebar {
        sidebar::show(ui, cx, sidebar);
    }
    // Last, so the active tab paints over the title bar's bottom border.
    title_bar::show(ui, cx, regions.title);
}
