# quickfiles

Prototype of a dark file-manager window built with `egui`/`eframe` 0.37 (Rust 2024).
All data is dummy data; the layout was measured pixel-by-pixel from the reference screenshot (1152x760).

    cargo run --release

## Layout of the code

| File | Responsibility |
|---|---|
| `src/theme.rs` | **All** colours (`Palette`), sizes (`Metrics`), fonts and egui style. Re-skin here only. |
| `src/model.rs` | Plain data types (`FileEntry`, `Listing`, `Sort`, ...). No egui. |
| `src/data.rs` | Dummy data + dummy directory generator. Swap for real FS / drive queries later. |
| `src/worker.rs` | Background thread: receives `Command`s, sends `Event`s, wakes the UI with `request_repaint`. |
| `src/state.rs` | All mutable UI state; owns the cached filtered/sorted `view`. |
| `src/app.rs` | Glue: polls the worker, turns `Action`s into state changes. |
| `src/ui/layout.rs` | Splits the window into regions (title, sidebar, toolbar, header, list, status). |
| `src/ui/{title_bar,sidebar,toolbar,file_list,status_bar}.rs` | One module per region. |
| `src/ui/icons.rs` | Vector icons drawn with the painter (no assets, no icon font). |
| `src/ui/widgets.rs` | Shared helpers: crisp 1px lines, truncated text, icon buttons. |

## Design notes

- **Threading**: the UI thread never touches the file system. Requests are coalesced on the worker
  (only the newest navigation is processed) and stale results are dropped by request id.
  Large dummy directories (up to 20k entries) are generated in parallel with `thread::scope`.
- **Performance**: the file list is virtualised (`ScrollArea::show_rows`); filtering/sorting runs only
  when the filter, sort or listing changes, never per frame; text is laid out once per frame per visible cell.
- **Interaction**: click selects, Ctrl+click toggles, double-click on a folder opens it, header cells sort,
  breadcrumb segments / Up / Back / Forward navigate, tabs can be added/closed, the sidebar toggle works,
  drag the title bar to move the window.
